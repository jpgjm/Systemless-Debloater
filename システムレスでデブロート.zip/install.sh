#!/system/bin/sh

on_install() {
  unzip -o "$ZIPFILE" -d "$MODPATH"

  Create_Download_folder="/storage/emulated/0/Download"
  if [ ! -d "$Create_Download_folder" ]; then
      mkdir -p "$Create_Download_folder"
  fi
  
  output_file="$MODPATH/Package_missing_list.txt"
  input_file="$Create_Download_folder/この端末にインストールされているアプリのパッケージ名とAPKの保存場所.txt"

  if [ -f "$input_file" ]; then
      ui_print "- Input file already exists. Skipping APK scan."
  else
      > "$input_file"

      for apk in $(find / -type f -name "*.apk" 2>/dev/null); do
    pkg=$(pm list packages -f | grep "$apk" | sed -n 's/.*=//p')
    if [ -n "$pkg" ]; then
        echo "Package: $pkg" >> "$input_file"
        echo "APK: $apk" >> "$input_file"
        echo >> "$input_file"
    fi
done
  fi
  
  awk '
    /^Package: *$/ { pkg_empty = 1; next }
    /^APK: / && pkg_empty { print "Package:"; print $0; print ""; pkg_empty = 0 }
    /^$/ { pkg_empty = 0 }
  ' "$input_file" > "$output_file"
}