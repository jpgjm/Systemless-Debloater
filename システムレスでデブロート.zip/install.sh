#!/system/bin/sh

on_install() {
  unzip -o "$ZIPFILE" -d "$MODPATH"

  # aapt / aapt2 の実行権限
  [ -f "$MODPATH/bin/aapt" ] && chmod 755 "$MODPATH/bin/aapt"
  [ -f "$MODPATH/bin/aapt2" ] && chmod 755 "$MODPATH/bin/aapt2"

  # 使用する aapt を判定
  if [ -x "$MODPATH/bin/aapt" ]; then
    AAPT="$MODPATH/bin/aapt"
  elif [ -x "$MODPATH/bin/aapt2" ]; then
    AAPT="$MODPATH/bin/aapt2"
  else
    ui_print "- aapt または aapt2 が見つかりません"
    exit 1
  fi

  # 出力先
  DOWNLOAD_DIR="/storage/emulated/0/Download"
  mkdir -p "$DOWNLOAD_DIR"
  input_file="$DOWNLOAD_DIR/この端末にインストールされているアプリのパッケージ名とAPKの保存場所.txt"
  output_file="$MODPATH/Package_missing_list.txt"

  # ファイルがあれば書き出しスキップ
  write_output=false
  if [ ! -f "$input_file" ]; then
    > "$input_file"
    write_output=true
  else
    ui_print "- アプリ一覧ファイルが存在するため、作成をスキップします"
  fi

  # pm list packages -f の出力を一時保存（効率化）
  tmp_pkg_map="$MODPATH/pkg_map.txt"
  pm list packages -f | sed 's/package://g' > "$tmp_pkg_map"

  # APK を全検索し処理
  # 1回目のループ: システムアプリの更新データを削除
find / -type f -name "*.apk" 2>/dev/null | while read -r apk; do
  pkg=$(pm list packages -f | grep -F "$apk" | sed -n 's/.*=//p')
  if [ -n "$pkg" ]; then
    if pm list packages -s | grep -q "$pkg"; then
      ui_print "- Uninstalling updates: $pkg"
      pm uninstall "$pkg" >/dev/null 2>&1
    fi
  fi
done

# 更新後の状態でパッケージマップを作成
pm list packages -f | sed 's/package://g' > "$tmp_pkg_map"

# 2回目のループ: APK情報をファイルに書き出し
find / -type f -name "*.apk" 2>/dev/null | while read -r apk; do
  pkg=$(grep -F "$apk" "$tmp_pkg_map" | sed -n 's/.*=//p')
  if [ -n "$pkg" ]; then
    if $write_output; then
      label=$("$AAPT" dump badging "$apk" 2>/dev/null | grep -m1 "application-label:" | cut -d"'" -f2)
      [ -z "$label" ] && label="(不明)"
      echo "App: $label" >> "$input_file"
      echo "Package: $pkg" >> "$input_file"
      echo "APK: $apk" >> "$input_file"
      echo >> "$input_file"
    fi
  fi
done
  # 不完全エントリ補完
  awk '
    /^Package: *$/ { pkg_empty = 1; next }
    /^APK: / && pkg_empty { print "Package:"; print $0; print ""; pkg_empty = 0 }
    /^$/ { pkg_empty = 0 }
  ' "$input_file" > "$output_file"
}