#!/system/bin/sh

on_install() {
  unzip -o "$ZIPFILE" -d "$MODPATH"

  # aapt 実行権限を自動で付与
  if [ -f "$MODPATH/bin/aapt" ]; then
    chmod 755 "$MODPATH/bin/aapt"
  fi

  Create_Download_folder="/storage/emulated/0/Download"
  if [ ! -d "$Create_Download_folder" ]; then
    mkdir -p "$Create_Download_folder"
  fi

  output_file="$MODPATH/Package_missing_list.txt"
  input_file="$Create_Download_folder/この端末にインストールされているアプリのパッケージ名とAPKの保存場所.txt"

  if [ -f "$input_file" ]; then
    ui_print "- Input file already exists. Skipping APK scan."
  else
    > "$input_file"

    AAPT="$MODPATH/bin/aapt"

    for apk in $(find / -type f -name "*.apk" 2>/dev/null); do
  pkg=$(pm list packages -f | grep "$apk" | sed -n 's/.*=//p')
  if [ -n "$pkg" ]; then
    # aaptでアプリ名を取得
    label=$("$AAPT" dump badging "$apk" 2>/dev/null | grep -m1 "application-label:" | cut -d"'" -f2)
    [ -z "$label" ] && label="(unknown)"

    echo "App: $label" >> "$input_file"
    echo "Package: $pkg" >> "$input_file"
    echo "APK: $apk" >> "$input_file"
    echo >> "$input_file"
  fi
done
  fi

  # パッケージ情報が空行で始まるなどの欠落修正（元処理）
  awk '
    /^Package: *$/ { pkg_empty = 1; next }
    /^APK: / && pkg_empty { print "Package:"; print $0; print ""; pkg_empty = 0 }
    /^$/ { pkg_empty = 0 }
  ' "$input_file" > "$output_file"
}