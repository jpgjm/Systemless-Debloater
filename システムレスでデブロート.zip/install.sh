#!/system/bin/sh

on_install() {
  # ZIPファイルを展開
  unzip -o "$ZIPFILE" -d "$MODPATH"

  # aapt と aapt2 バイナリを配置し、実行権限を付与
  if [ -f "$MODPATH/bin/aapt" ]; then
    chmod 755 "$MODPATH/bin/aapt"
  fi

  if [ -f "$MODPATH/bin/aapt2" ]; then
    chmod 755 "$MODPATH/bin/aapt2"
  fi

  # aapt または aapt2 を自動判別
  AAPT=""
  if [ -x "$MODPATH/bin/aapt" ]; then
    AAPT="$MODPATH/bin/aapt"
  elif [ -x "$MODPATH/bin/aapt2" ]; then
    AAPT="$MODPATH/bin/aapt2"
  else
    ui_print "- aapt または aapt2 が見つかりません"
    exit 1
  fi

  # ダウンロードフォルダの作成
  Create_Download_folder="/storage/emulated/0/Download"
  if [ ! -d "$Create_Download_folder" ]; then
    mkdir -p "$Create_Download_folder"
  fi

  output_file="$MODPATH/Package_missing_list.txt"
  input_file="$Create_Download_folder/この端末にインストールされているアプリのパッケージ名とAPKの保存場所.txt"

  if [ -f "$input_file" ]; then
    ui_print "- Input file already exists. Skipping APK scan."
  else
    > "$input_file"

    # APKファイルを検索して処理
    for apk in $(find / -type f -name "*.apk" 2>/dev/null); do
      pkg=$(pm list packages -f | grep "$apk" | sed -n 's/.*=//p')
      if [ -n "$pkg" ]; then
        # aapt または aapt2 を使用してアプリ名を取得
        label=$("$AAPT" dump badging "$apk" 2>/dev/null | grep -m1 "application-label:" | cut -d"'" -f2)
        [ -z "$label" ] && label="(unknown)"

        echo "App: $label" >> "$input_file"
        echo "Package: $pkg" >> "$input_file"
        echo "APK: $apk" >> "$input_file"
        echo >> "$input_file"
      fi
    done
  fi

  # 空行や不完全なパッケージ情報を修正
  awk '
    /^Package: *$/ { pkg_empty = 1; next }
    /^APK: / && pkg_empty { print "Package:"; print $0; print ""; pkg_empty = 0 }
    /^$/ { pkg_empty = 0 }
  ' "$input_file" > "$output_file"
}