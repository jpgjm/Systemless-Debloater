#!/system/bin/sh

MODDIR=${0%/*}
MODPATH=$MODDIR

ListFile="$MODPATH/Package_missing_list.txt"
DummyApk="$MODPATH/dummy.apk"
touch "$DummyApk"

if [ -f "$ListFile" ]; then
  while IFS= read -r line; do
    case "$line" in
      APK:\ *) 
        apk_path="${line#APK: }"
        [ -f "$apk_path" ] && mount -o bind "$DummyApk" "$apk_path"
        ;;
    esac
  done < "$ListFile"
fi